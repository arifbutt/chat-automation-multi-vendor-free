const { chromium } = require('playwright-extra');
const stealth = require('puppeteer-extra-plugin-stealth')();
const express = require('express');
const path = require('path');
require('dotenv').config();

chromium.use(stealth);

const app = express();
app.use(express.json());

const PORT = process.env.PORT || 3000;
const USER_DATA_DIR = path.join(__dirname, 'user_data');

const delay = (ms) => new Promise(res => setTimeout(res, ms));

app.post('/ask', async (req, res) => {
    const { prompt } = req.body;

    if (!prompt) {
        return res.status(400).json({ error: "Prompt is required." });
    }

    console.log(`Processing prompt: ${prompt}`);

    // CRITICAL: Added clipboard permissions to the context
    const context = await chromium.launchPersistentContext(USER_DATA_DIR, {
        headless: process.env.HEADLESS === 'true',
        channel: 'chrome',
        viewport: { width: 1280, height: 720 },
        userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
        permissions: ['clipboard-read', 'clipboard-write'], 
        args: [
            '--disable-blink-features=AutomationControlled',
            '--no-sandbox',
            '--disable-setuid-sandbox'
        ]
    });

    const page = await context.newPage();

    try {
        // Use the 2026 AI-triggering URL
        const searchUrl = `https://www.google.com/search?q=${encodeURIComponent(prompt)}&udm=14&glu=1&gl=us`;
        
        console.log('Navigating to Google AI Mode...');
        await page.goto(searchUrl, { waitUntil: 'networkidle', timeout: 60000 });

        // Handle CAPTCHA if it appears
        if (page.url().includes('google.com/sorry')) {
            console.log('CAPTCHA detected! Please solve it in the browser window.');
            await page.waitForURL(url => !url.href.includes('google.com/sorry'), { timeout: 120000 });
        }

        // Check for "Generate" button (Common for some 2026 queries)
        const genBtn = page.locator('button:has-text("Generate"), [aria-label="Generate AI Overview"]');
        if (await genBtn.isVisible({ timeout: 5000 })) {
            console.log('Clicking "Generate"...');
            await genBtn.click();
        }

        console.log('Waiting for AI response to complete...');
        // The .bKxaof class is the unique identifier for the copy button you found
        const copyBtnSelector = 'button.bKxaof[aria-label="Copy text"]';
        
        // Wait for the copy button to appear (indicating the AI is done)
        await page.waitForSelector(copyBtnSelector, { timeout: 20000 });
        console.log('Copy button detected. Capturing clipboard...');

        // Execute the click and clipboard read inside the browser
        const finalResult = await page.evaluate(async (selector) => {
            const btn = document.querySelector(selector);
            if (!btn) return "Error: Copy button disappeared.";

            // 1. Click the button to trigger Google's internal copy logic
            btn.click();

            // 2. Wait a heartbeat for the clipboard to populate
            await new Promise(r => setTimeout(r, 500));

            // 3. Read and return the text
            try {
                return await navigator.clipboard.readText();
            } catch (err) {
                return "Clipboard Read Failed. Manual text fallback: " + document.body.innerText.substring(0, 500);
            }
        }, copyBtnSelector);

        console.log('Response captured successfully via Clipboard.');
        await context.close();
        res.json({ result: finalResult });

    } catch (error) {
        console.error('Operation failed:', error);
        try {
            await page.screenshot({ path: 'error_screenshot.png' });
            console.log('Screenshot saved to error_screenshot.png');
        } catch (e) {}
        await context.close();
        res.status(500).json({ error: "Failed to capture AI response.", details: error.message });
    }
});

app.listen(PORT, () => {
    console.log(`API running on port ${PORT}`);
});