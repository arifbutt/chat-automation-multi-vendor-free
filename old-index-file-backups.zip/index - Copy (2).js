const { chromium } = require('playwright-extra');
const stealth = require('puppeteer-extra-plugin-stealth')();
const express = require('express');
const path = require('path');
require('dotenv').config();

chromium.use(stealth);

const app = express();
app.use(express.json());

const PORT = process.env.PORT || 3000;
const USER_DATA_DIR = path.join(__dirname, 'user_data');

// Helper to wait for AI to finish typing
const delay = (ms) => new Promise(res => setTimeout(res, ms));

app.post('/ask', async (req, res) => {
    const { prompt } = req.body;

    if (!prompt) {
        return res.status(400).json({ error: "Prompt is required." });
    }

    console.log(`Processing prompt: ${prompt}`);

    // Launch with persistent context to save cookies/session
    const context = await chromium.launchPersistentContext(USER_DATA_DIR, {
        headless: process.env.HEADLESS === 'true',
        channel: 'chrome',
        viewport: { width: 1280, height: 720 },
        args: ['--disable-blink-features=AutomationControlled']
    });

    const page = await context.newPage();

    try {
        // Navigate to the AI Mode page
        await page.goto('https://www.google.com/ai', { waitUntil: 'networkidle', timeout: 60000 });

        // Check for CAPTCHA or "Sorry" page
        if (page.url().includes('google.com/sorry')) {
            console.log('CAPTCHA detected! Please solve it in the browser window.');
            await page.waitForURL(url => !url.href.includes('google.com/sorry'), { timeout: 120000 });
        }

        // 1. Locate the "Ask anything" bar
        // Use .first() to avoid "strict mode violation" if multiple boxes exist
        const chatInput = page.locator('textarea[placeholder*="Ask"], textarea.ITIRGe, [role="combobox"]').first();
        await chatInput.waitFor({ state: 'visible', timeout: 30000 });
        
        await chatInput.fill(prompt);
        await page.keyboard.press('Enter');

        // 2. Wait for the response to generate
        // Look for common response containers in Google's AI UI
        const responseLocator = page.locator('[data-test-id="conversation-turn"], [role="region"] >> text=AI Overview, .ULSxyf').first();
        
        // Wait for the indicator that it started responding
        await responseLocator.waitFor({ state: 'visible', timeout: 60000 });
        
        // Give it extra time for the "streaming" effect
        await delay(10000); 

        const result = await responseLocator.innerText();

        await context.close();
        res.json({ result });

    } catch (error) {
        console.error('Interaction failed:', error);
        await context.close();
        res.status(500).json({ error: "AI Mode failed.", details: error.message });
    }
});

app.listen(PORT, () => {
    console.log(`API running on port ${PORT}`);
    console.log(`User data stored in: ${USER_DATA_DIR}`);
    console.log(`Send POST requests to http://localhost:${PORT}/ask`);
});
