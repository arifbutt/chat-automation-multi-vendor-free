const { chromium } = require('playwright-extra');
const stealth = require('puppeteer-extra-plugin-stealth')();
const express = require('express');
const path = require('path');
require('dotenv').config();

chromium.use(stealth);

const app = express();
app.use(express.json());

const PORT = process.env.PORT || 3000;
const USER_DATA_DIR = path.join(__dirname, 'user_data');

// Helper to wait for AI to finish typing
const delay = (ms) => new Promise(res => setTimeout(res, ms));

app.post('/ask', async (req, res) => {
    const { prompt } = req.body;

    if (!prompt) {
        return res.status(400).json({ error: "Prompt is required." });
    }

    console.log(`Processing prompt: ${prompt}`);

    // Launch with persistent context to save cookies/session
    const context = await chromium.launchPersistentContext(USER_DATA_DIR, {
        headless: process.env.HEADLESS === 'true',
        channel: 'chrome',
        viewport: { width: 1280, height: 720 },
        args: [
            '--disable-blink-features=AutomationControlled',
            '--no-sandbox',
            '--disable-setuid-sandbox'
        ]
    });

    const page = await context.newPage();

    try {
        // Navigate to the AI Mode page
        console.log('Navigating to Google AI Mode...');
        await page.goto('https://www.google.com/ai', { waitUntil: 'networkidle', timeout: 60000 });

        // Check for CAPTCHA
        if (page.url().includes('google.com/sorry')) {
            console.log('CAPTCHA detected! Please solve it in the browser window.');
            await page.waitForURL(url => !url.href.includes('google.com/sorry'), { timeout: 120000 });
        }

        // 1. Locate the "Ask anything" bar
        console.log('Locating input box...');
        const chatInput = page.locator('textarea[placeholder*="Ask"], textarea.ITIRGe, [role="combobox"]').first();
        await chatInput.waitFor({ state: 'visible', timeout: 30000 });
        
        console.log('Filling prompt...');
        await chatInput.fill(prompt);
        
        console.log('Submitting prompt...');
        // Try pressing Enter on the element itself for better reliability
        await chatInput.press('Enter');
        
        // Sometimes Enter isn't enough, try finding the "Send" button as a backup
        const sendButton = page.locator('button[aria-label*="Send"], button[aria-label*="Search"]').first();
        if (await sendButton.isVisible()) {
            await sendButton.click();
        }

        // 2. Wait for the response to generate
        console.log('Waiting for response to appear...');
        // Broader list of selectors for Google's AI/Gemini responses
        const responseSelectors = [
            '[data-test-id="conversation-turn"]',
            '[role="region"] >> text=AI Overview',
            '.ULSxyf',
            '.RE977e',
            '.DS1S6',
            'div[data-content-type="ai-overview"]',
            '.MU5U0b'
        ];
        
        const responseLocator = page.locator(responseSelectors.join(', ')).first();
        
        // Wait for any of the response containers to become visible
        await responseLocator.waitFor({ state: 'visible', timeout: 60000 });
        
        console.log('Response detected. Waiting for it to finish streaming...');
        // Give it extra time for the "streaming" effect
        await delay(12000); 

        const result = await responseLocator.innerText();
        console.log('Response captured successfully.');

        await context.close();
        res.json({ result });

    } catch (error) {
        console.error('Interaction failed:', error);
        // Try to take a screenshot for debugging if it fails
        try {
            await page.screenshot({ path: 'error_screenshot.png' });
            console.log('Error screenshot saved to error_screenshot.png');
        } catch (sError) {
            console.error('Failed to save screenshot:', sError);
        }
        await context.close();
        res.status(500).json({ error: "AI Mode failed.", details: error.message });
    }
});

app.listen(PORT, () => {
    console.log(`API running on port ${PORT}`);
    console.log(`User data stored in: ${USER_DATA_DIR}`);
    console.log(`Send POST requests to http://localhost:${PORT}/ask`);
});
