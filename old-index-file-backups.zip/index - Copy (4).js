const { chromium } = require('playwright-extra');
const stealth = require('puppeteer-extra-plugin-stealth')();
const express = require('express');
const path = require('path');
require('dotenv').config();

chromium.use(stealth);

const app = express();
app.use(express.json());

const PORT = process.env.PORT || 3000;
const USER_DATA_DIR = path.join(__dirname, 'user_data');

// Helper to wait for AI to finish typing
const delay = (ms) => new Promise(res => setTimeout(res, ms));

app.post('/ask', async (req, res) => {
    const { prompt } = req.body;

    if (!prompt) {
        return res.status(400).json({ error: "Prompt is required." });
    }

    console.log(`Processing prompt: ${prompt}`);

    // Launch with persistent context to save cookies/session
    const context = await chromium.launchPersistentContext(USER_DATA_DIR, {
        headless: process.env.HEADLESS === 'true',
        channel: 'chrome',
        viewport: { width: 1280, height: 720 },
        args: [
            '--disable-blink-features=AutomationControlled',
            '--no-sandbox',
            '--disable-setuid-sandbox'
        ]
    });

    const page = await context.newPage();

    try {
        // Navigate to the AI Mode page
        console.log('Navigating to Google AI Mode...');
        // Using udm=50 which often triggers the AI mode directly
        await page.goto('https://www.google.com/search?q=' + encodeURIComponent(prompt) + '&udm=50', { waitUntil: 'networkidle', timeout: 60000 });

        // Check for CAPTCHA
        if (page.url().includes('google.com/sorry')) {
            console.log('CAPTCHA detected! Please solve it in the browser window.');
            await page.waitForURL(url => !url.href.includes('google.com/sorry'), { timeout: 120000 });
        }

        // Check if we need to click "AI Mode" button (if not already there via URL)
        const aiModeButton = page.locator('text="AI Mode", [aria-label="AI Mode"]').first();
        if (await aiModeButton.isVisible({ timeout: 5000 })) {
            console.log('Clicking AI Mode button...');
            await aiModeButton.click();
        }

        // If for some reason we are on a page without the result, fill the box
        const chatInput = page.locator('textarea[placeholder*="Ask"], textarea.ITIRGe, [role="combobox"]').first();
        if (await chatInput.isVisible({ timeout: 5000 })) {
            const currentVal = await chatInput.inputValue();
            if (!currentVal || currentVal.length < 2) {
                console.log('Filling prompt into box...');
                await chatInput.fill(prompt);
                await chatInput.press('Enter');
            }
        }

        // 2. Wait for the response to generate
        console.log('Waiting for response to appear...');
        
        // These selectors are specific to Google Search AI Mode (SGE/AI Overviews)
        const responseSelectors = [
            '.ULSxyf',                             // Main AI container
            '.RE977e',                             // Primary text content
            'div[data-content-type="ai-overview"]', // Official content type
            '.MU5U0b',                             // Header/Overview area
            '[role="complementary"]',              // The AI sidebar/region
            '.DS1S6'                               // Another common SGE container
        ];

        const responseLocator = page.locator(responseSelectors.join(', ')).first();
        
        try {
            // Wait for the AI block to become visible
            await responseLocator.waitFor({ state: 'visible', timeout: 45000 });
            console.log('Response detected. Waiting for it to finish streaming...');
            
            // Wait for the text to settle
            await delay(12000); 

            const result = await responseLocator.innerText();
            console.log('Response captured successfully.');

            await context.close();
            res.json({ result });
            
        } catch (waitError) {
            console.log('Primary selectors failed. Attempting broad capture or screenshot...');
            await page.screenshot({ path: 'response_debug.png' });
            
            // Fallback: If specific classes fail, grab the main content area
            const fallback = await page.locator('#rcnt, #center_col').first();
            let resultText = "Could not isolate AI response.";
            if (await fallback.isVisible()) {
                resultText = await fallback.innerText();
            }
            
            await context.close();
            res.json({ result: resultText });
        }

    } catch (error) {
        console.error('Interaction failed:', error);
        try {
            await page.screenshot({ path: 'error_screenshot.png' });
            console.log('Error screenshot saved to error_screenshot.png');
        } catch (sError) {
            console.error('Failed to save screenshot:', sError);
        }
        await context.close();
        res.status(500).json({ error: "AI Mode failed.", details: error.message });
    }
});

app.listen(PORT, () => {
    console.log(`API running on port ${PORT}`);
    console.log(`User data stored in: ${USER_DATA_DIR}`);
    console.log(`Send POST requests to http://localhost:${PORT}/ask`);
});
