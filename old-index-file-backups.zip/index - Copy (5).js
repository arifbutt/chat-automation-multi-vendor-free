const { chromium } = require('playwright-extra');
const stealth = require('puppeteer-extra-plugin-stealth')();
const express = require('express');
const path = require('path');
require('dotenv').config();

chromium.use(stealth);

const app = express();
app.use(express.json());

const PORT = process.env.PORT || 3000;
const USER_DATA_DIR = path.join(__dirname, 'user_data');

// Helper to wait
const delay = (ms) => new Promise(res => setTimeout(res, ms));

// "Cleaner" function to extract human-readable text from Google's messy batchexecute JSON
function extractCleanText(rawString) {
    if (!rawString) return null;

    // Look for content inside double quotes that looks like an AI response
    // We specifically look for longer strings that aren't just IDs or CSS classes
    const regex = /"([^"]{50,})"/g;
    let matches = [];
    let match;

    while ((match = regex.exec(rawString)) !== null) {
        const text = match[1];
        // Filter out strings that look like base64, URLs, or pure code
        if (!text.includes('http') && !text.includes(';base64') && text.includes(' ')) {
            // Clean up escaped characters like \n, \", etc.
            const clean = text.replace(/\\n/g, '\n').replace(/\\"/g, '"').replace(/\\u003c/g, '<').replace(/\\u003e/g, '>');
            matches.push(clean);
        }
    }

    // Usually, the longest string in the AI response is the actual answer
    if (matches.length > 0) {
        return matches.sort((a, b) => b.length - a.length)[0];
    }
    return null;
}

app.post('/ask', async (req, res) => {
    const { prompt } = req.body;

    if (!prompt) {
        return res.status(400).json({ error: "Prompt is required." });
    }

    console.log(`Processing prompt: ${prompt}`);

    const context = await chromium.launchPersistentContext(USER_DATA_DIR, {
        headless: process.env.HEADLESS === 'true',
        channel: 'chrome',
        viewport: { width: 1280, height: 720 },
        args: ['--disable-blink-features=AutomationControlled']
    });

    const page = await context.newPage();
    let interceptedText = null;

    // LISTEN TO NETWORK RESPONSES
    page.on('response', async (response) => {
        const url = response.url();
        if (url.includes('batchexecute') || url.includes('search')) {
            try {
                const text = await response.text();
                // Check if this response contains significant text related to the prompt or general answer patterns
                // We're looking for the data packet that actually contains the AI's generation
                if (text.length > 1000 && (text.includes('wrb.fr') || text.includes('\"\\n'))) {
                    const cleaned = extractCleanText(text);
                    if (cleaned && (!interceptedText || cleaned.length > interceptedText.length)) {
                        interceptedText = cleaned;
                        console.log('Intercepted a potential AI response from network.');
                    }
                }
            } catch (e) { /* Ignore non-textual or failed reads */ }
        }
    });

    try {
        console.log('Navigating to Google with AI trigger...');
        await page.goto('https://www.google.com/search?q=' + encodeURIComponent(prompt) + '&udm=50', { 
            waitUntil: 'networkidle', 
            timeout: 60000 
        });

        // Check for CAPTCHA
        if (page.url().includes('google.com/sorry')) {
            console.log('CAPTCHA detected! Please solve it in the browser window.');
            await page.waitForURL(url => !url.href.includes('google.com/sorry'), { timeout: 120000 });
        }

        // Wait for background requests to settle
        console.log('Waiting for network data...');
        await delay(8000);

        if (interceptedText) {
            console.log('Returning intercepted network data.');
            await context.close();
            return res.json({ result: interceptedText, source: 'network_interception' });
        }

        // FALLBACK: If network interception didn't catch it, use the DOM scraper
        console.log('Network interception failed or was incomplete. Falling back to DOM scraping...');
        const responseSelectors = ['.ULSxyf', '.RE977e', 'div[data-content-type="ai-overview"]', '.MU5U0b', '.DS1S6'];
        const responseLocator = page.locator(responseSelectors.join(', ')).first();
        
        if (await responseLocator.isVisible({ timeout: 10000 })) {
            const result = await responseLocator.innerText();
            console.log('Captured result via DOM fallback.');
            await context.close();
            return res.json({ result, source: 'dom_scraper' });
        }

        // LAST RESORT: Grab the main content area
        const fallback = await page.locator('#center_col').first();
        let resultText = "No AI response isolated.";
        if (await fallback.isVisible()) {
            resultText = await fallback.innerText();
            console.log('Captured result via last-resort content area.');
        }

        await context.close();
        res.json({ result: resultText, source: 'fallback' });

    } catch (error) {
        console.error('Operation failed:', error);
        await context.close();
        res.status(500).json({ error: "AI Mode failed.", details: error.message });
    }
});

app.listen(PORT, () => {
    console.log(`API running on port ${PORT}`);
    console.log(`Send POST requests to http://localhost:${PORT}/ask`);
});
