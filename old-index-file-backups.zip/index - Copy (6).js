const { chromium } = require('playwright-extra');
const stealth = require('puppeteer-extra-plugin-stealth')();
const express = require('express');
const path = require('path');
require('dotenv').config();

chromium.use(stealth);

const app = express();
app.use(express.json());

const PORT = process.env.PORT || 3000;
const USER_DATA_DIR = path.join(__dirname, 'user_data');

// Helper to wait
const delay = (ms) => new Promise(res => setTimeout(res, ms));

app.post('/ask', async (req, res) => {
    const { prompt } = req.body;

    if (!prompt) {
        return res.status(400).json({ error: "Prompt is required." });
    }

    console.log(`Processing prompt: ${prompt}`);

    const context = await chromium.launchPersistentContext(USER_DATA_DIR, {
        headless: process.env.HEADLESS === 'true',
        channel: 'chrome',
        viewport: { width: 1280, height: 720 },
        args: ['--disable-blink-features=AutomationControlled']
    });

    const page = await context.newPage();

    try {
        console.log('Navigating to Google with AI trigger...');
        await page.goto('https://www.google.com/search?q=' + encodeURIComponent(prompt) + '&udm=50', { 
            waitUntil: 'networkidle', 
            timeout: 60000 
        });

        // Check for CAPTCHA
        if (page.url().includes('google.com/sorry')) {
            console.log('CAPTCHA detected! Please solve it in the browser window.');
            await page.waitForURL(url => !url.href.includes('google.com/sorry'), { timeout: 120000 });
        }

        console.log('Waiting for AI text to stabilize...');
        await delay(12000); // Give the AI enough time to finish the animation

        const cleanResult = await page.evaluate(() => {
            // 1. Target the AI Mode specific containers
            const selectors = ['.ULSxyf', 'div[data-content-type="ai-overview"]', '.RE977e', '#center_col'];
            let container = null;
            
            for (const selector of selectors) {
                const el = document.querySelector(selector);
                if (el && el.innerText.length > 100) {
                    container = el;
                    break;
                }
            }

            if (!container) return "Could not find AI container.";

            // 2. Extract text ONLY from visible text elements, avoiding styles/scripts
            const textNodes = Array.from(container.querySelectorAll('h1, h2, h3, p, li, span, div'));
            
            return textNodes
                .map(node => {
                    // Check if node is visible and not a script/style tag
                    if (node.tagName === 'SCRIPT' || node.tagName === 'STYLE') return '';
                    return node.innerText.trim();
                })
                .filter(text => 
                    text.length > 20 && // Ignore very short snippets
                    !text.includes('{') && // Filter out CSS/JS code
                    !text.includes('display:block') && // Filter out inline styles
                    !text.includes('@keyframes') // Filter out animations
                )
                .join('\n');
        });

        // Clean up the text: remove duplicates and cut off at sources/feedback
        const lines = cleanResult.split('\n');
        const uniqueLines = [...new Set(lines)];
        const joinedResult = uniqueLines.join('\n');
        
        const finalAnswer = joinedResult
            .split('Sources')[0]
            .split('Feedback')[0]
            .split('Show more')[0]
            .trim();

        console.log('Response captured successfully.');
        await context.close();
        res.json({ result: finalAnswer || "No human-readable AI response found." });

    } catch (error) {
        console.error('Operation failed:', error);
        try {
            await page.screenshot({ path: 'error_screenshot.png' });
        } catch (e) {}
        await context.close();
        res.status(500).json({ error: "AI Mode failed.", details: error.message });
    }
});

app.listen(PORT, () => {
    console.log(`API running on port ${PORT}`);
    console.log(`Send POST requests to http://localhost:${PORT}/ask`);
});
