const { chromium } = require('playwright-extra');
const stealth = require('puppeteer-extra-plugin-stealth')();
const express = require('express');
const path = require('path');
require('dotenv').config();

chromium.use(stealth);

const app = express();
app.use(express.json());

const PORT = process.env.PORT || 3000;
const USER_DATA_DIR = path.join(__dirname, 'user_data');

// Helper to wait
const delay = (ms) => new Promise(res => setTimeout(res, ms));

app.post('/ask', async (req, res) => {
    const { prompt } = req.body;

    if (!prompt) {
        return res.status(400).json({ error: "Prompt is required." });
    }

    console.log(`Processing prompt: ${prompt}`);

    const context = await chromium.launchPersistentContext(USER_DATA_DIR, {
        headless: process.env.HEADLESS === 'true',
        channel: 'chrome',
        viewport: { width: 1280, height: 720 },
        args: ['--disable-blink-features=AutomationControlled']
    });

    const page = await context.newPage();

    try {
        console.log('Navigating to Google with AI trigger (udm=14)...');
        // udm=14 is a common AI-specific view parameter
        await page.goto('https://www.google.com/search?q=' + encodeURIComponent(prompt) + '&udm=14', { 
            waitUntil: 'networkidle', 
            timeout: 60000 
        });

        // Check for CAPTCHA
        if (page.url().includes('google.com/sorry')) {
            console.log('CAPTCHA detected! Please solve it in the browser window.');
            await page.waitForURL(url => !url.href.includes('google.com/sorry'), { timeout: 120000 });
        }

        // Check for a "Generate" button that might need to be clicked
        const genBtn = page.locator('text="Generate", [aria-label="Generate AI Overview"], button:has-text("Generate")').first();
        if (await genBtn.isVisible({ timeout: 10000 })) {
            console.log('Clicking "Generate" button...');
            await genBtn.click();
        }

        console.log('Waiting for AI text to stabilize (15s)...');
        await delay(15000); 

        const cleanResult = await page.evaluate(() => {
            // 1. Target the AI Overview using a TreeWalker to find text landmarks
            const walk = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null, false);
            let node;
            let foundAI = false;
            let textChunks = [];

            while(node = walk.nextNode()) {
                const val = node.textContent.trim();
                
                // Landmarks that indicate the start of the AI response
                if (val === 'AI Overview' || val === 'AI Mode' || val.includes('Generative AI is experimental')) {
                    foundAI = true;
                    continue; 
                }

                if (foundAI) {
                    // Stop landmarks
                    if (val === 'Sources' || val === 'Feedback' || val.includes('Related searches') || val === 'Search results') {
                        break;
                    }
                    // Filter out short technical strings or code-like snippets
                    if (val.length > 5 && !val.includes('{') && !val.includes('}')) {
                        textChunks.push(val);
                    }
                }
            }

            if (textChunks.length > 0) {
                // Join and remove common duplicates often found in search DOM
                return [...new Set(textChunks)].join(' ');
            }

            // 2. FALLBACK: Grab the main content area text
            const center = document.querySelector('#center_col, #rcnt, .ULSxyf');
            if (center) {
                return center.innerText.split('Sources')[0].split('Feedback')[0].trim();
            }

            return "Could not isolate AI text.";
        });

        // Final cleanup for any leftover UI strings
        const finalAnswer = cleanResult
            .replace(/Listen\s*$/, '')
            .replace(/Learn more\s*$/, '')
            .trim();

        console.log('Response captured successfully.');
        await context.close();
        res.json({ result: finalAnswer });

    } catch (error) {
        console.error('Operation failed:', error);
        try {
            await page.screenshot({ path: 'error_screenshot.png' });
            console.log('Error screenshot saved.');
        } catch (e) {}
        await context.close();
        res.status(500).json({ error: "AI Mode failed.", details: error.message });
    }
});

app.listen(PORT, () => {
    console.log(`API running on port ${PORT}`);
    console.log(`Send POST requests to http://localhost:${PORT}/ask`);
});
