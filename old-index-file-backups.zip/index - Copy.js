const { chromium } = require('playwright-extra');
const stealth = require('puppeteer-extra-plugin-stealth')();
const express = require('express');
const path = require('path');
require('dotenv').config();

chromium.use(stealth);

const app = express();
app.use(express.json());

const PORT = process.env.PORT || 3000;
const USER_DATA_DIR = path.join(__dirname, 'user_data');

// Helper to wait for AI to finish typing
const delay = (ms) => new Promise(res => setTimeout(res, ms));

app.post('/ask', async (req, res) => {
    const { prompt } = req.body;

    if (!prompt) {
        return res.status(400).json({ error: "Prompt is required." });
    }

    console.log(`Processing prompt: ${prompt}`);

    // Launch with persistent context to save cookies/session
    const context = await chromium.launchPersistentContext(USER_DATA_DIR, {
        headless: process.env.HEADLESS === 'true',
        channel: 'chrome',
        viewport: { width: 1280, height: 720 },
        args: ['--disable-blink-features=AutomationControlled']
    });

    const page = await context.newPage();

    try {
        await page.goto('https://www.google.com');

        // Check for CAPTCHA
        if (page.url().includes('google.com/sorry')) {
            console.log('CAPTCHA detected! Please solve it in the browser window.');
            // Wait longer for CAPTCHA solving (up to 2 minutes)
            await page.waitForURL('**/google.com/**', { timeout: 120000 });
        }

        // 1. Click the "AI Mode" button
        // Using a more robust locator for the AI Mode button
        const aiModeButton = page.locator('text="AI Mode", [aria-label="AI Mode"]');
        await aiModeButton.waitFor({ state: 'visible', timeout: 20000 });
        await aiModeButton.click();

        // 2. Wait for the AI chat/search input to appear
        // Exclude hidden captchas and be more specific
        const chatInput = page.locator('textarea:visible, [role="combobox"]:visible').first();
        await chatInput.waitFor({ state: 'visible', timeout: 20000 });
        await chatInput.fill(prompt);
        await page.keyboard.press('Enter');

        // 3. Wait for the response to generate
        const responseLocator = page.locator('[role="region"] >> text=AI Overview, [data-test-id="conversation-turn"], .ULSxyf');
        
        // Wait for the indicator that it started responding
        await responseLocator.first().waitFor({ state: 'visible', timeout: 45000 });
        
        // Give it extra time for the "streaming" effect
        await delay(8000); 

        const result = await responseLocator.first().innerText();

        await context.close();
        res.json({ result });

    } catch (error) {
        console.error('Error during AI Mode interaction:', error);
        await context.close();
        res.status(500).json({ error: "AI Mode failed to respond.", details: error.message });
    }
});

app.listen(PORT, () => {
    console.log(`API running on port ${PORT}`);
    console.log(`User data stored in: ${USER_DATA_DIR}`);
    console.log(`Send POST requests to http://localhost:${PORT}/ask`);
});
