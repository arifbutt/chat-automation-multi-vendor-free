const { chromium } = require('playwright-extra');
const stealth = require('puppeteer-extra-plugin-stealth')();
const express = require('express');
const path = require('path');
require('dotenv').config();

chromium.use(stealth);

const app = express();
app.use(express.json());

const PORT = process.env.PORT || 3000;
const USER_DATA_DIR = path.join(__dirname, 'user_data');

// Helper to wait
const delay = (ms) => new Promise(res => setTimeout(res, ms));

app.post('/ask', async (req, res) => {
    const { prompt } = req.body;

    if (!prompt) {
        return res.status(400).json({ error: "Prompt is required." });
    }

    console.log(`Processing prompt: ${prompt}`);

    const context = await chromium.launchPersistentContext(USER_DATA_DIR, {
        headless: process.env.HEADLESS === 'true',
        channel: 'chrome',
        viewport: { width: 1280, height: 720 },
        userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
        args: [
            '--disable-blink-features=AutomationControlled',
            '--no-sandbox',
            '--disable-setuid-sandbox'
        ]
    });

    const page = await context.newPage();

    try {
        // 1. Force the AI-specific URL parameters (2026 Strategy)
        const searchUrl = `https://www.google.com/search?q=${encodeURIComponent(prompt)}&udm=14&glu=1&gl=us`;
        
        console.log('Navigating to Google AI Mode (Super-Force URL)...');
        await page.goto(searchUrl, { waitUntil: 'networkidle', timeout: 60000 });

        // Check for CAPTCHA
        if (page.url().includes('google.com/sorry')) {
            console.log('CAPTCHA detected! Please solve it in the browser window.');
            await page.waitForURL(url => !url.href.includes('google.com/sorry'), { timeout: 120000 });
        }

        // 2. Check for the "Generate" button (sometimes required in 2026)
        try {
            const generateButton = page.locator('button:has-text("Generate"), [aria-label="Generate AI Overview"], button:has-text("AI Overview")').first();
            if (await generateButton.isVisible({ timeout: 5000 })) {
                console.log('Clicking "Generate" button...');
                await generateButton.click();
            }
        } catch (e) {
            console.log('No Generate button found, checking for auto-gen content...');
        }

        console.log('Waiting for AI text to stabilize (12s)...');
        await delay(12000); 

        const cleanResult = await page.evaluate(() => {
            // Target specific AI containers used in 2026
            const aiContainer = document.querySelector('[data-local-attribute="d_lp_ai_overview"]') || 
                                document.querySelector('.hXAn0b') || // Common AI wrapper class
                                document.querySelector('[role="region"][aria-label*="AI"]') ||
                                document.querySelector('.ULSxyf');

            if (aiContainer) {
                // Clone the container to clean it without affecting the live page
                const clone = aiContainer.cloneNode(true);
                
                // Remove UI noise: buttons, source lists, icons, feedback links
                const exclusions = clone.querySelectorAll('button, .Vv79Check, .source-list, [aria-haspopup], .feedback-link, .xX798c');
                exclusions.forEach(el => el.remove());
                
                return clone.innerText.trim();
            }

            // Fallback: Use TreeWalker if container matching fails
            const walk = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null, false);
            let node;
            let foundAI = false;
            let textChunks = [];

            while(node = walk.nextNode()) {
                const val = node.textContent.trim();
                if (val === 'AI Overview' || val === 'AI Mode' || val.includes('Generative AI is experimental')) {
                    foundAI = true;
                    continue; 
                }
                if (foundAI) {
                    if (val === 'Sources' || val === 'Feedback' || val.includes('Related searches') || val === 'Search results') break;
                    if (val.length > 5 && !val.includes('{')) textChunks.push(val);
                }
            }

            if (textChunks.length > 0) return [...new Set(textChunks)].join(' ');

            return "AI Overview did not trigger. Google displayed standard search results instead.";
        });

        // Final cleanup
        const finalAnswer = cleanResult
            .replace(/Listen\s*$/, '')
            .replace(/Learn more\s*$/, '')
            .trim();

        console.log('Response captured successfully.');
        await context.close();
        res.json({ result: finalAnswer });

    } catch (error) {
        console.error('Operation failed:', error);
        try {
            await page.screenshot({ path: 'error_screenshot.png' });
        } catch (e) {}
        await context.close();
        res.status(500).json({ error: "AI Mode failed.", details: error.message });
    }
});

app.listen(PORT, () => {
    console.log(`API running on port ${PORT}`);
    console.log(`Send POST requests to http://localhost:${PORT}/ask`);
});
