const { chromium } = require('playwright-extra');
const stealth = require('puppeteer-extra-plugin-stealth')();
const express = require('express');
const path = require('path');
require('dotenv').config();

chromium.use(stealth);

const app = express();
app.use(express.json());

const PORT = process.env.PORT || 3000;
const USER_DATA_DIR = path.join(__dirname, 'user_data');

const delay = (ms) => new Promise(res => setTimeout(res, ms));

app.post('/ask', async (req, res) => {
    const { prompt } = req.body;
    if (!prompt) return res.status(400).json({ error: "Prompt is required." });

    console.log(`Processing prompt: ${prompt}`);

    const context = await chromium.launchPersistentContext(USER_DATA_DIR, {
        headless: process.env.HEADLESS === 'true',
        channel: 'chrome',
        viewport: { width: 1280, height: 720 },
        // Grant clipboard permissions so navigator.clipboard.readText() works
        permissions: ['clipboard-read', 'clipboard-write'],
        args: ['--disable-blink-features=AutomationControlled']
    });

    const page = await context.newPage();

    try {
        // 1. Navigate to the AI Mode page
        await page.goto('https://www.google.com/ai', { waitUntil: 'networkidle', timeout: 60000 });

        // 2. Locate the input bar
        // Targets common textarea IDs and placeholders in the AI interface
        const chatInput = page.locator('textarea[placeholder*="Ask"], textarea.ITIRGe, [role="combobox"]').first();
        await chatInput.waitFor({ state: 'visible', timeout: 30000 });
        
        await chatInput.fill(prompt);
        await page.keyboard.press('Enter');

        console.log('Prompt sent. Waiting for AI to finish typing...');

        // 3. Wait for the Copy Button (.bKxaof) to appear
        // This button only appears once the AI is done generating
        const copyBtnSelector = 'button.bKxaof[aria-label*="Copy"]';
        await page.waitForSelector(copyBtnSelector, { timeout: 60000, state: 'visible' });
        
        // Give it a tiny bit of breathing room for the animation to finish
        await delay(1000);

        // 4. Trigger the click and read the clipboard
        const result = await page.evaluate(async (selector) => {
            const btn = document.querySelector(selector);
            if (!btn) return "Copy button found by selector but disappeared in DOM.";

            btn.click(); // This triggers Google's internal copy-to-clipboard action
            
            // Wait for clipboard to update
            await new Promise(r => setTimeout(r, 500));
            
            try {
                return await navigator.clipboard.readText();
            } catch (err) {
                return "Clipboard access denied. Check browser context permissions.";
            }
        }, copyBtnSelector);

        console.log('Markdown response captured.');
        await context.close();
        res.json({ result });

    } catch (error) {
        console.error('Interaction failed:', error);
        // Take a screenshot to see what the page looks like at the moment of failure
        await page.screenshot({ path: 'ai_error.png' });
        await context.close();
        res.status(500).json({ error: "Interaction failed.", details: error.message });
    }
});

app.listen(PORT, () => {
    console.log(`API running on port ${PORT}`);
});