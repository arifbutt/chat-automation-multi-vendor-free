const { chromium } = require('playwright-extra');
const stealth = require('puppeteer-extra-plugin-stealth')();
const express = require('express');
const path = require('path');
require('dotenv').config();

chromium.use(stealth);

const app = express();
app.use(express.json());

const PORT = process.env.PORT || 3000;
const USER_DATA_DIR = path.join(__dirname, 'user_data');

let browserContext = null;
let aiPage = null;

async function getBrowserInstance() {
    const isBrowserActive = browserContext && browserContext.browser() && browserContext.browser().isConnected();

    if (!isBrowserActive) {
        console.log('Launching browser instance...');
        try {
            browserContext = await chromium.launchPersistentContext(USER_DATA_DIR, {
                headless: process.env.HEADLESS === 'true',
                channel: 'chrome',
                viewport: { width: 1280, height: 720 },
                permissions: ['clipboard-read', 'clipboard-write'],
                args: ['--disable-blink-features=AutomationControlled']
            });

            aiPage = await browserContext.newPage();
            await aiPage.goto('https://www.google.com/ai', { waitUntil: 'networkidle' });
        } catch (err) {
            console.error('Failed to launch browser:', err);
            throw err;
        }
    }
    return { browserContext, aiPage };
}

app.post('/ask', async (req, res) => {
    const { prompt } = req.body;
    if (!prompt) return res.status(400).json({ error: "Prompt is required." });

    console.log(`Processing prompt: ${prompt}`);

    try {
        const { aiPage } = await getBrowserInstance();

        // Ensure we are on the right page
        if (!aiPage.url().includes('google.com/ai')) {
            await aiPage.goto('https://www.google.com/ai', { waitUntil: 'networkidle' });
        }

        // OPTIONAL: Try to click "New Chat" if it exists to clear history
        const newChatBtn = aiPage.locator('button[aria-label*="New chat"], [data-tooltip*="Clear"]').first();
        if (await newChatBtn.isVisible()) {
            await newChatBtn.click();
            await aiPage.waitForTimeout(1000);
        }

        const chatInput = aiPage.locator('textarea[placeholder*="Ask"], textarea.ITIRGe, [role="combobox"]').first();
        await chatInput.fill(prompt);
        await aiPage.keyboard.press('Enter');

        console.log('Waiting for AI...');

        // CRITICAL CHANGE: Target the LAST copy button on the page
        const copyBtnSelector = 'button.bKxaof[aria-label*="Copy"]';
        
        // Wait for at least one to be visible
        await aiPage.waitForSelector(copyBtnSelector, { timeout: 60000 });

        const result = await aiPage.evaluate(async (selector) => {
            // Find all copy buttons and pick the very last one (the newest response)
            const buttons = document.querySelectorAll(selector);
            const lastBtn = buttons[buttons.length - 1];
            
            if (!lastBtn) return "Error: No copy button found.";

            lastBtn.click();
            await new Promise(r => setTimeout(r, 600)); // Wait for clipboard
            return await navigator.clipboard.readText();
        }, copyBtnSelector);

        res.json({ result });

    } catch (error) {
        console.error('Interaction failed:', error);
        if (error.message.includes('closed')) {
            browserContext = null;
            aiPage = null;
        }
        res.status(500).json({ error: "Failed.", details: error.message });
    }
});

app.listen(PORT, async () => {
    console.log(`API running on http://localhost:${PORT}`);
    try { await getBrowserInstance(); } catch (e) {}
});